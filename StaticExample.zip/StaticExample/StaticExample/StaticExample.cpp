// StaticExample.cpp : This file contains the 'main' function. Program execution begins and ends there.
//


#include <iostream>
using namespace std;
void funct() {
	static int count=1;
	int num = 100;
	count++;
	num++;
	cout << "count: " << count << endl;
	cout << "num: " << num<< endl;
}
int recur(int n) {
	int r =0;
	if (n > 0) {
		r = n + recur(n - 1);
	}
	return r;
}
int main()
{
	/*funct();
    cout << "-------------------------------------------\n";
	funct();
	cout << "-------------------------------------------\n"; funct();
	cout << "-------------------------------------------\n"; funct();
	cout << "-------------------------------------------\n";*/
	/*int num,result;
	cout << "enter number" << endl;
	cin >> num;
	result = recur(num);
	cout << "Sum : " << result;*/
	int arr[5];
	int myarr[] = { 10,20,30,40 };

	cout << "size" << size(arr) << endl;
	cout << "size" << size(myarr) << endl;

	for (int i = 0; i < size(myarr) - 1; i++) {
		cout << myarr[i] << endl;
	}

	
}



