#include<iostream>
using namespace std;
int main() {
	int arr[] = { 1,2,1,2,0,7,2,0 },count;
	for (int k = 0; k < size(arr); k++) {
		count = 0;
		for (int l = 0; l < size(arr); l++) {
			if (arr[k] == arr[l]) {
				count++;
			}
			else
			{
					k = l - 1;
					break;
				}
		}
		cout << arr[k] << ":" << count << endl;

	}
}