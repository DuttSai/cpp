#include <iostream>
using namespace std;
int main() {
	int a[] = { 1,2,3,4,5,7,8,9,10};
	cout << "Even numbers are : " << endl;
	for (int i = 0; i < size(a); i++) {
		if (a[i] % 2 == 0) {
			cout << a[i] << endl;
		}
		
	}
	cout << "Odd numbers are : " << endl;
	for (int i = 0; i < size(a); i++) {
		if (a[i] % 2 != 0) {
			cout << a[i] << endl;
		}

	}

}