// FirstProblem.cpp : This file contains the 'main' function. Program execution begins and ends there.
//


//FIRST PROGRAM

#include <iostream>
using namespace std;

//int main()
//{
//	int num;
//    cout << "Enter any number \n";
//	cin >> num;
//
//	cout << "The Resultant Pattern is";
//	cout << endl;
//
//	for (int i = 1; i <= num; i++) {
//		for (int j = 1; j <= i; j++) {
//			cout << i;
//
//		}
//		cout<< endl;
//	}
//
//}


//SECOND PROGRAM
//


//int main()
//{
//	int num, temp = 0;
//	cout << "Enter any number \n";
//	cin >> num;
//
//	cout << "The Resultant Pattern is";
//	cout << endl;
//
//	for (int i = 1; i <= num; i++) {
//		for (int j = 1; j <= i; j++) {
//			temp += 1;
//			cout << temp << "\t";
//
//		}
//		cout << endl;
//	}
//
//}


//THIRD PROGRAM

//int main()
//{
//	int num,temp;
//	cout << "enter any number";
//	cin >> num;
//	temp = num;
//	for (int i = num; i > 0; i--)
//	{
//		for (int j = 1; j < 2*num; j++)
//		{
//			if (j == num)
//			{
//				for (int l = temp - num; l >= 0; l--)
//				{
//					cout << "*" << " ";
//					j++;
//				}
//				num--;
//			}
//			else
//			{
//				cout << " ";
//			}
//		}
//		cout << endl;
//	}
//}







//FOURTH PROGRAM


//int main()
//{
//	int i,num,even=0,odd=0,total;
//
//	cout << "Enter any number \n";
//	cin >> num;
//
//	for (i = 1; i < num; i++) {
//		if (i % 2 == 0) {
//			even += i;
//		}
//		else {
//			odd += i;
//		}
//	}
//
//	cout << "Sum of Even number is "<<even<<endl;
//	cout << "Sum of Odd number is " << odd << endl;
//	total = even + odd;
//	cout << "Sum of Even number and Odd number is " << total;
//}

//FIFTH PROGRAM

//int main()
//{
//	int  num;
//	cout << "Enter any number \n";
//	cin >> num;
//
//	if (num % 15 == 0) {
//		cout << "Given number is Divisible by 15 \n";
//	}
//	else
//	{
//		cout << "Given number not Divisible by 15 \n";
//	}
//
//}

//SIXTH PROGRAM

//int main()
//{
//	int  num;
//	cout << " Numbers(1-100) which are divisible by 15 are\n";
//	for (num = 1; num < 100; num++) {
//		if (num % 15 == 0) {
//			cout<< num << "\n";
//		}
//		
//	}
//}



// 1.Program in PDF

//int main() {
//	int num, rem,count=0, sum = 0;
//	cout << "enter number";
//	cin >> num;
//	while (num!=0)
//	{
//		count++;
//		rem = num % 10;
//		sum = rem + sum;
//		num = num / 10;
//	}
//	if (count < 5) {
//		cout << "Total number of digits should not be less than 5";
//	}
//	else {
//		cout << "Total Sum is" << sum;
//	}
//}

// 2.Program in PDF

int main() {
	int n = 20,count=0,k=2,j;
	for (int i = 1; i <= 20; i+=2) {
		cout << i<<"\t";
		count++;
		if (count ==3) {
			for (j = k; j <k+5; j += 2) {
				cout << j<<"\t";
			}
			count = 0;
			k = j;
		}
		
	}
}